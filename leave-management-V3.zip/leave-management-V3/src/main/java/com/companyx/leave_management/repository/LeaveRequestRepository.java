public class LeaveRequestRepository {
    
}

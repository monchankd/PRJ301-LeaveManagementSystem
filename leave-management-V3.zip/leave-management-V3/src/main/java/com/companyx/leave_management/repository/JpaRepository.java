public class JpaRepository {
    
}

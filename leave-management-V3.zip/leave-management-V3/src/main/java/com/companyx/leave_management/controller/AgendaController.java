package main.java.com.companyx.leave_management.controller;

public class AgendaController {
    
}
